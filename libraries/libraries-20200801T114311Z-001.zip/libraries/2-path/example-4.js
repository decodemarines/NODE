const path = require('path');

// Full path to a file
const fullPath = __filename;

console.log(path.dirname(fullPath));
