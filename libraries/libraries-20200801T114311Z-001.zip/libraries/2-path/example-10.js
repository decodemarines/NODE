const path = require('path');

console.log(
    path.parse(
        "/Users/radist/Projects/Backend/lesson-5 Node's Common Built-in Libraries/source/2-path/example-10.js",
    ),
);
