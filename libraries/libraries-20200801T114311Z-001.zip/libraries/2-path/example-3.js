const path = require('path');

// Full path to a file
const fullPath =
    "/Users/radist/Projects/Backend/lesson-5 Node's Common Built-in Libraries/source/2-path/example-3.js";

console.log(path.dirname(fullPath));
