const path = require('path');

console.log(
    path.normalize(
        "/Users/radist/Projects/Backend/lesson-5 Node's Common Built-in Libraries/source/../..",
    ),
);

console.log(path.normalize('C:\\Users\\radist\\'));
