const path = require('path');

// POSIX specific methods
console.log(path.posix);

console.log('\n============================\n');

// Windows specific methods
console.log(path.win32);
