const path = require('path');

// for Windows → \
// for POSIX → /
console.log(path.sep);
