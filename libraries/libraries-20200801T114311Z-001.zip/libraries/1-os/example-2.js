const os = require('os');

// For the 10.x LTS
// https://nodejs.org/dist/latest-v10.x/docs/api/os.html#os_os_constants_1
console.log(os.constants);
