const os = require('os');

// /Users/radist
console.log(os.homedir());
