const os = require('os');

// For your system it my be different.
// /var/folders/3_/2h7g4k190gq1f35vbjy5fy7r0000gn/T
console.log(os.tmpdir());
