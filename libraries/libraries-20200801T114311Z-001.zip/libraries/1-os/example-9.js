const os = require('os');

// PCName-Inc.local
console.log(os.hostname());
