const os = require('os');

// For the 10.x LTS
// 'arm', 'arm64', 'ia32', 'mips', 'mipsel', 'ppc', 'ppc64', 's390', 's390x', 'x32', 'x64'
console.log(os.arch());
